﻿namespace LogInDiseño
{
    partial class FormRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRegistro));
            this.panelLogo = new System.Windows.Forms.Panel();
            this.picBoxLogo = new System.Windows.Forms.PictureBox();
            this.lblRegistro = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.lblInicioSesion = new System.Windows.Forms.LinkLabel();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtContraseña2 = new System.Windows.Forms.TextBox();
            this.txtContraseña1 = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtCedula = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.picBoxNombre = new System.Windows.Forms.PictureBox();
            this.picBoxContraseña1 = new System.Windows.Forms.PictureBox();
            this.picBoxContraseña2 = new System.Windows.Forms.PictureBox();
            this.picBoxEmail = new System.Windows.Forms.PictureBox();
            this.picBoxCedula = new System.Windows.Forms.PictureBox();
            this.picBoxApellido = new System.Windows.Forms.PictureBox();
            this.picBoxMostrarContraseña1 = new System.Windows.Forms.PictureBox();
            this.picBoxOcultarContraseña1 = new System.Windows.Forms.PictureBox();
            this.picBoxOcultarContraseña2 = new System.Windows.Forms.PictureBox();
            this.picBoxMostrarContraseña2 = new System.Windows.Forms.PictureBox();
            this.panelRegistro = new System.Windows.Forms.Panel();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNombre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxContraseña1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxContraseña2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCedula)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxApellido)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMostrarContraseña1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOcultarContraseña1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOcultarContraseña2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMostrarContraseña2)).BeginInit();
            this.panelRegistro.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(143)))), ((int)(((byte)(84)))));
            this.panelLogo.Controls.Add(this.picBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(244, 418);
            this.panelLogo.TabIndex = 0;
            // 
            // picBoxLogo
            // 
            this.picBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("picBoxLogo.Image")));
            this.picBoxLogo.Location = new System.Drawing.Point(23, 127);
            this.picBoxLogo.Name = "picBoxLogo";
            this.picBoxLogo.Size = new System.Drawing.Size(199, 160);
            this.picBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxLogo.TabIndex = 11;
            this.picBoxLogo.TabStop = false;
            // 
            // lblRegistro
            // 
            this.lblRegistro.AutoSize = true;
            this.lblRegistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegistro.Location = new System.Drawing.Point(13, 23);
            this.lblRegistro.Name = "lblRegistro";
            this.lblRegistro.Size = new System.Drawing.Size(127, 20);
            this.lblRegistro.TabIndex = 1;
            this.lblRegistro.Text = "REGISTRARSE";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(168)))), ((int)(((byte)(99)))));
            this.btnRegistrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistrar.FlatAppearance.BorderSize = 0;
            this.btnRegistrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(92)))), ((int)(((byte)(82)))));
            this.btnRegistrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(92)))), ((int)(((byte)(54)))));
            this.btnRegistrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRegistrar.Location = new System.Drawing.Point(16, 264);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(460, 49);
            this.btnRegistrar.TabIndex = 16;
            this.btnRegistrar.Text = "REGISTRAR";
            this.btnRegistrar.UseVisualStyleBackColor = false;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // lblInicioSesion
            // 
            this.lblInicioSesion.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(92)))), ((int)(((byte)(54)))));
            this.lblInicioSesion.AutoSize = true;
            this.lblInicioSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInicioSesion.LinkColor = System.Drawing.SystemColors.ControlText;
            this.lblInicioSesion.Location = new System.Drawing.Point(116, 325);
            this.lblInicioSesion.Name = "lblInicioSesion";
            this.lblInicioSesion.Size = new System.Drawing.Size(265, 20);
            this.lblInicioSesion.TabIndex = 17;
            this.lblInicioSesion.TabStop = true;
            this.lblInicioSesion.Text = "Ya tiene una cuenta? Inicia Sesión";
            this.lblInicioSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblInicioSesion_LinkClicked);
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(46, 66);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(430, 20);
            this.txtNombre.TabIndex = 18;
            this.txtNombre.Text = "NOMBRE";
            this.txtNombre.Enter += new System.EventHandler(this.txtNombre_Enter);
            this.txtNombre.Leave += new System.EventHandler(this.txtNombre_Leave);
            // 
            // txtContraseña2
            // 
            this.txtContraseña2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtContraseña2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseña2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseña2.Location = new System.Drawing.Point(46, 233);
            this.txtContraseña2.Name = "txtContraseña2";
            this.txtContraseña2.Size = new System.Drawing.Size(430, 20);
            this.txtContraseña2.TabIndex = 23;
            this.txtContraseña2.Text = "REPITA LA CONTRASEÑA";
            this.txtContraseña2.Enter += new System.EventHandler(this.txtContraseña2_Enter);
            this.txtContraseña2.Leave += new System.EventHandler(this.txtContraseña2_Leave);
            // 
            // txtContraseña1
            // 
            this.txtContraseña1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtContraseña1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContraseña1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseña1.Location = new System.Drawing.Point(46, 198);
            this.txtContraseña1.Name = "txtContraseña1";
            this.txtContraseña1.Size = new System.Drawing.Size(430, 20);
            this.txtContraseña1.TabIndex = 22;
            this.txtContraseña1.Text = "CONTRASEÑA";
            this.txtContraseña1.Enter += new System.EventHandler(this.txtContraseña1_Enter);
            this.txtContraseña1.Leave += new System.EventHandler(this.txtContraseña1_Leave);
            // 
            // txtEmail
            // 
            this.txtEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(46, 163);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(430, 20);
            this.txtEmail.TabIndex = 21;
            this.txtEmail.Text = "EMAIL";
            this.txtEmail.Enter += new System.EventHandler(this.txtEmail_Enter);
            this.txtEmail.Leave += new System.EventHandler(this.txtEmail_Leave);
            // 
            // txtCedula
            // 
            this.txtCedula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtCedula.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCedula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCedula.Location = new System.Drawing.Point(46, 131);
            this.txtCedula.Name = "txtCedula";
            this.txtCedula.Size = new System.Drawing.Size(430, 20);
            this.txtCedula.TabIndex = 20;
            this.txtCedula.Text = "CÉDULA";
            this.txtCedula.Enter += new System.EventHandler(this.txtCedula_Enter);
            this.txtCedula.Leave += new System.EventHandler(this.txtCedula_Leave);
            // 
            // txtApellido
            // 
            this.txtApellido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.txtApellido.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtApellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellido.Location = new System.Drawing.Point(46, 99);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(430, 20);
            this.txtApellido.TabIndex = 19;
            this.txtApellido.Text = "APELLIDO";
            this.txtApellido.Enter += new System.EventHandler(this.txtApellido_Enter);
            this.txtApellido.Leave += new System.EventHandler(this.txtApellido_Leave);
            // 
            // picBoxNombre
            // 
            this.picBoxNombre.Image = ((System.Drawing.Image)(resources.GetObject("picBoxNombre.Image")));
            this.picBoxNombre.Location = new System.Drawing.Point(16, 69);
            this.picBoxNombre.Name = "picBoxNombre";
            this.picBoxNombre.Size = new System.Drawing.Size(23, 22);
            this.picBoxNombre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxNombre.TabIndex = 24;
            this.picBoxNombre.TabStop = false;
            // 
            // picBoxContraseña1
            // 
            this.picBoxContraseña1.Image = ((System.Drawing.Image)(resources.GetObject("picBoxContraseña1.Image")));
            this.picBoxContraseña1.Location = new System.Drawing.Point(16, 201);
            this.picBoxContraseña1.Name = "picBoxContraseña1";
            this.picBoxContraseña1.Size = new System.Drawing.Size(23, 22);
            this.picBoxContraseña1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxContraseña1.TabIndex = 25;
            this.picBoxContraseña1.TabStop = false;
            // 
            // picBoxContraseña2
            // 
            this.picBoxContraseña2.Image = ((System.Drawing.Image)(resources.GetObject("picBoxContraseña2.Image")));
            this.picBoxContraseña2.Location = new System.Drawing.Point(16, 236);
            this.picBoxContraseña2.Name = "picBoxContraseña2";
            this.picBoxContraseña2.Size = new System.Drawing.Size(23, 22);
            this.picBoxContraseña2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxContraseña2.TabIndex = 26;
            this.picBoxContraseña2.TabStop = false;
            // 
            // picBoxEmail
            // 
            this.picBoxEmail.Image = ((System.Drawing.Image)(resources.GetObject("picBoxEmail.Image")));
            this.picBoxEmail.Location = new System.Drawing.Point(16, 166);
            this.picBoxEmail.Name = "picBoxEmail";
            this.picBoxEmail.Size = new System.Drawing.Size(23, 22);
            this.picBoxEmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxEmail.TabIndex = 27;
            this.picBoxEmail.TabStop = false;
            // 
            // picBoxCedula
            // 
            this.picBoxCedula.Image = ((System.Drawing.Image)(resources.GetObject("picBoxCedula.Image")));
            this.picBoxCedula.Location = new System.Drawing.Point(16, 134);
            this.picBoxCedula.Name = "picBoxCedula";
            this.picBoxCedula.Size = new System.Drawing.Size(23, 22);
            this.picBoxCedula.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxCedula.TabIndex = 28;
            this.picBoxCedula.TabStop = false;
            // 
            // picBoxApellido
            // 
            this.picBoxApellido.Image = ((System.Drawing.Image)(resources.GetObject("picBoxApellido.Image")));
            this.picBoxApellido.Location = new System.Drawing.Point(16, 102);
            this.picBoxApellido.Name = "picBoxApellido";
            this.picBoxApellido.Size = new System.Drawing.Size(23, 22);
            this.picBoxApellido.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxApellido.TabIndex = 29;
            this.picBoxApellido.TabStop = false;
            // 
            // picBoxMostrarContraseña1
            // 
            this.picBoxMostrarContraseña1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBoxMostrarContraseña1.Image = ((System.Drawing.Image)(resources.GetObject("picBoxMostrarContraseña1.Image")));
            this.picBoxMostrarContraseña1.Location = new System.Drawing.Point(448, 192);
            this.picBoxMostrarContraseña1.Name = "picBoxMostrarContraseña1";
            this.picBoxMostrarContraseña1.Size = new System.Drawing.Size(23, 22);
            this.picBoxMostrarContraseña1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxMostrarContraseña1.TabIndex = 30;
            this.picBoxMostrarContraseña1.TabStop = false;
            this.picBoxMostrarContraseña1.Click += new System.EventHandler(this.picBoxMostrarContraseña1_Click);
            // 
            // picBoxOcultarContraseña1
            // 
            this.picBoxOcultarContraseña1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBoxOcultarContraseña1.Image = ((System.Drawing.Image)(resources.GetObject("picBoxOcultarContraseña1.Image")));
            this.picBoxOcultarContraseña1.Location = new System.Drawing.Point(448, 192);
            this.picBoxOcultarContraseña1.Name = "picBoxOcultarContraseña1";
            this.picBoxOcultarContraseña1.Size = new System.Drawing.Size(23, 22);
            this.picBoxOcultarContraseña1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxOcultarContraseña1.TabIndex = 31;
            this.picBoxOcultarContraseña1.TabStop = false;
            this.picBoxOcultarContraseña1.Visible = false;
            this.picBoxOcultarContraseña1.Click += new System.EventHandler(this.picBoxOcultarContraseña1_Click);
            // 
            // picBoxOcultarContraseña2
            // 
            this.picBoxOcultarContraseña2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBoxOcultarContraseña2.Image = ((System.Drawing.Image)(resources.GetObject("picBoxOcultarContraseña2.Image")));
            this.picBoxOcultarContraseña2.Location = new System.Drawing.Point(448, 228);
            this.picBoxOcultarContraseña2.Name = "picBoxOcultarContraseña2";
            this.picBoxOcultarContraseña2.Size = new System.Drawing.Size(23, 22);
            this.picBoxOcultarContraseña2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxOcultarContraseña2.TabIndex = 33;
            this.picBoxOcultarContraseña2.TabStop = false;
            this.picBoxOcultarContraseña2.Visible = false;
            this.picBoxOcultarContraseña2.Click += new System.EventHandler(this.picBoxOcultarContraseña2_Click);
            // 
            // picBoxMostrarContraseña2
            // 
            this.picBoxMostrarContraseña2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBoxMostrarContraseña2.Image = ((System.Drawing.Image)(resources.GetObject("picBoxMostrarContraseña2.Image")));
            this.picBoxMostrarContraseña2.Location = new System.Drawing.Point(448, 228);
            this.picBoxMostrarContraseña2.Name = "picBoxMostrarContraseña2";
            this.picBoxMostrarContraseña2.Size = new System.Drawing.Size(23, 22);
            this.picBoxMostrarContraseña2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxMostrarContraseña2.TabIndex = 32;
            this.picBoxMostrarContraseña2.TabStop = false;
            this.picBoxMostrarContraseña2.Click += new System.EventHandler(this.picBoxMotrarContraseña2_Click);
            // 
            // panelRegistro
            // 
            this.panelRegistro.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelRegistro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.panelRegistro.Controls.Add(this.txtNombre);
            this.panelRegistro.Controls.Add(this.picBoxOcultarContraseña2);
            this.panelRegistro.Controls.Add(this.lblRegistro);
            this.panelRegistro.Controls.Add(this.picBoxMostrarContraseña2);
            this.panelRegistro.Controls.Add(this.btnRegistrar);
            this.panelRegistro.Controls.Add(this.picBoxOcultarContraseña1);
            this.panelRegistro.Controls.Add(this.lblInicioSesion);
            this.panelRegistro.Controls.Add(this.picBoxMostrarContraseña1);
            this.panelRegistro.Controls.Add(this.txtApellido);
            this.panelRegistro.Controls.Add(this.picBoxApellido);
            this.panelRegistro.Controls.Add(this.txtCedula);
            this.panelRegistro.Controls.Add(this.picBoxCedula);
            this.panelRegistro.Controls.Add(this.txtEmail);
            this.panelRegistro.Controls.Add(this.picBoxEmail);
            this.panelRegistro.Controls.Add(this.txtContraseña1);
            this.panelRegistro.Controls.Add(this.picBoxContraseña2);
            this.panelRegistro.Controls.Add(this.txtContraseña2);
            this.panelRegistro.Controls.Add(this.picBoxContraseña1);
            this.panelRegistro.Controls.Add(this.picBoxNombre);
            this.panelRegistro.Location = new System.Drawing.Point(284, 12);
            this.panelRegistro.Name = "panelRegistro";
            this.panelRegistro.Size = new System.Drawing.Size(559, 394);
            this.panelRegistro.TabIndex = 34;
            // 
            // FormRegistro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(225)))), ((int)(((byte)(200)))));
            this.ClientSize = new System.Drawing.Size(863, 418);
            this.Controls.Add(this.panelRegistro);
            this.Controls.Add(this.panelLogo);
            this.MinimumSize = new System.Drawing.Size(823, 446);
            this.Name = "FormRegistro";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registro";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FormRegistro_MouseDown);
            this.Resize += new System.EventHandler(this.FormRegistro_Resize);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxNombre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxContraseña1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxContraseña2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxCedula)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxApellido)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMostrarContraseña1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOcultarContraseña1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxOcultarContraseña2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxMostrarContraseña2)).EndInit();
            this.panelRegistro.ResumeLayout(false);
            this.panelRegistro.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox picBoxLogo;
        private System.Windows.Forms.Label lblRegistro;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.LinkLabel lblInicioSesion;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtContraseña2;
        private System.Windows.Forms.TextBox txtContraseña1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCedula;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.PictureBox picBoxNombre;
        private System.Windows.Forms.PictureBox picBoxContraseña1;
        private System.Windows.Forms.PictureBox picBoxContraseña2;
        private System.Windows.Forms.PictureBox picBoxEmail;
        private System.Windows.Forms.PictureBox picBoxCedula;
        private System.Windows.Forms.PictureBox picBoxApellido;
        private System.Windows.Forms.PictureBox picBoxMostrarContraseña1;
        private System.Windows.Forms.PictureBox picBoxOcultarContraseña1;
        private System.Windows.Forms.PictureBox picBoxOcultarContraseña2;
        private System.Windows.Forms.PictureBox picBoxMostrarContraseña2;
        private System.Windows.Forms.Panel panelRegistro;
    }
}